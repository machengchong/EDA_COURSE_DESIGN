function varargout = untitled(varargin)
% UNTITLED MATLAB code for untitled.fig
%      UNTITLED, by itself, creates a new UNTITLED or raises the existing
%      singleton*.
%
%      H = UNTITLED returns the handle to a new UNTITLED or the handle to
%      the existing singleton*.
%
%      UNTITLED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in UNTITLED.M with the given input arguments.
%
%      UNTITLED('Property','Value',...) creates a new UNTITLED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before untitled_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to untitled_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help untitled

% Last Modified by GUIDE v2.5 17-Dec-2019 18:37:50

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @untitled_OpeningFcn, ...
                   'gui_OutputFcn',  @untitled_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before untitled is made visible.
function untitled_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to untitled (see VARARGIN)

% Choose default command line output for untitled
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes untitled wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = untitled_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[FileName,PathName,FilterIndex]=uigetfile( {'*.xlsx','csv-files (*.xlsx)'},'xlsx')
xlspath=PathName;
xlsname=FileName;
xls=fullfile(PathName,FileName)
handles.xls = xls
guidata(hObject,handles)

%set(handles.pfnameh,'string',xls);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
grade0=xlsread(handles.xls,'Sheet1','B2:L51');
%ȡ��
     Col_num=length(grade0(1,:));
     %length(grade(:,z))
     Random_num=randperm(length(grade0(:,1)))
     k=ceil(1/5*length(grade0(:,1)));
     if k>=50
          grade(1:k,:)=grade0(Random_num(1:k),:);
     elseif k<50
         if length(grade0(:,1))>50
            grade(1:50,:)=grade0(Random_num(1:50),:);
         else
            grade=grade0 ;
         end
     end
%����
for i=1:Col_num
     num(i)=sum(grade(:,Col_num)<10*i);
end

for i=1:Col_num
    if i>1
     stu_num(1,i)=num(i)-num(i-1);
    else
     stu_num(1,i)=num(i);
    end
end

all_num=length(grade)

for i=1:Col_num
    stu_num(2,i)=stu_num(1,i)/all_num*100;
end

column_name=['��01_09';'��10_19';'��20_29';'��30_39';'��40_49';'��50_59';'��60_69';'��70_79';'��80_89';'��90_99';'��  100'];
row_name=['����';'����'];
column_name_cell=cellstr(column_name)
row_name_cell=cellstr(row_name)

xlswrite(handles.xls, column_name_cell(1), 'sheet4','B1');
xlswrite(handles.xls, column_name_cell(2), 'sheet4','C1');
xlswrite(handles.xls, column_name_cell(3), 'sheet4','D1');
xlswrite(handles.xls, column_name_cell(4), 'sheet4','E1');
xlswrite(handles.xls, column_name_cell(5), 'sheet4','F1');
xlswrite(handles.xls, column_name_cell(6), 'sheet4','g1');
xlswrite(handles.xls, column_name_cell(7), 'sheet4','h1');
xlswrite(handles.xls, column_name_cell(8), 'sheet4','i1');
xlswrite(handles.xls, column_name_cell(9), 'sheet4','j1');
xlswrite(handles.xls, column_name_cell(10), 'sheet4','k1');
xlswrite(handles.xls, column_name_cell(11), 'sheet4','l1');
xlswrite(handles.xls,row_name_cell , 'sheet4','a2');
xlswrite(handles.xls,stu_num, 'sheet4','b2:L3');
set(figure(1),'position',[400 400 800 100]);
uitable(gcf,'Data',stu_num,'Position',[50 20 700 60],'Columnname',column_name,'Rowname',row_name);

figure(2)
bar(stu_num(1,:))
set(gca,'xticklabel',{'��01-09' '��10-19' '��20-29' '��30-39' '��40-49' '��50-59' '��60-69' '��70-79' '��80-89' '��90-99' '��  100'})
legend('����')
title('�����ֲ�')

Item_Score=[5 5 8 8 10 10 12 12 15 15 100]
for i=1:Col_num
    Item_Score(2,i)=sum(grade(:,i));
end
for i=1:Col_num
    Item_Score(3,i)= Item_Score(2,i)/50;
end
for i=1:Col_num
    Item_Score(4,i)= std(grade(:,i),0) ;
end
for i=1:Col_num
    Item_Score(5,i)= 1-Item_Score(3,i)/Item_Score(1,i);
end

grade_sort=sort(grade);
for i=1:Col_num
     len=length(grade(:,i));
     Item_Score(6,i)=mean(grade_sort(ceil(3/4*len):len,i));
     Item_Score(7,i)=mean(grade_sort(1:ceil(1/4*len),i));
end
for i=1:Col_num
    Item_Score(8,i)= (Item_Score(6,i)-Item_Score(7,i))/Item_Score(1,i);
end

column_name=['��һ';'���';'����';'����';'����';'����';'����';'���';'���';'��ʮ';'�ܷ�'];
row_name=['���ֵ ';'�÷ֺ� ';'ƽ���� ';'��׼�� ';'�Ѷ�  ';'�߷�ƽ��';'�ͷ�ƽ��';'���ֶ� '];
column_name_cell=cellstr(column_name)
row_name_cell=cellstr(row_name)

xlswrite(handles.xls, column_name_cell(1), 'sheet3','B1');
xlswrite(handles.xls, column_name_cell(2), 'sheet3','C1');
xlswrite(handles.xls, column_name_cell(3), 'sheet3','D1');
xlswrite(handles.xls, column_name_cell(4), 'sheet3','E1');
xlswrite(handles.xls, column_name_cell(5), 'sheet3','F1');
xlswrite(handles.xls, column_name_cell(6), 'sheet3','g1');
xlswrite(handles.xls, column_name_cell(7), 'sheet3','h1');
xlswrite(handles.xls, column_name_cell(8), 'sheet3','i1');
xlswrite(handles.xls, column_name_cell(9), 'sheet3','j1');
xlswrite(handles.xls, column_name_cell(10), 'sheet3','k1');
xlswrite(handles.xls, column_name_cell(11), 'sheet3','l1');
xlswrite(handles.xls,row_name_cell , 'sheet3','a2');
xlswrite(handles.xls, Item_Score, 'sheet3','b2:L9');
set(figure(3),'position',[400 400 800 250]);
uitable(gcf,'Data',Item_Score,'Position',[20 20 750 200],'Columnname',column_name,'Rowname',row_name);

Parameters(1)=length(grade(:,Col_num));
for i=1:Col_num
    num_var(i)=var(grade(:,i),0);
end
Parameters(2)=(length(grade(1,:))-1)/(length(grade(1,:))-2)*(1-sum(num_var(1:10))/num_var(Col_num))
Parameters(3)=max(grade(:,Col_num));
Parameters(4)=min(grade(:,Col_num));
Parameters(5)=Parameters(3)-Parameters(4);
Parameters(6)=sum(grade(:,Col_num)>=60)/Parameters(1)*100;

column_name=['������';'�Ŷ� ';'��߷�';'��ͷ�';'ȫ�� ';'������'];
column_name_cell=cellstr(column_name)
xlswrite(handles.xls, column_name_cell(1), 'sheet2','A1');
xlswrite(handles.xls, column_name_cell(2), 'sheet2','B1');
xlswrite(handles.xls, column_name_cell(3), 'sheet2','C1');
xlswrite(handles.xls, column_name_cell(4), 'sheet2','D1');
xlswrite(handles.xls, column_name_cell(5), 'sheet2','E1');
xlswrite(handles.xls, column_name_cell(6), 'sheet2','F1');
xlswrite(handles.xls, Parameters, 'sheet2','A2:F2');
set(figure(4),'position',[400 400 450 80]);
uitable(gcf,'Data',Parameters,'Position',[20 20 400 50],'Columnname',column_name);


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pfnameh.
function pfnameh_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pfnameh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes during object creation, after setting all properties.
function pfnameh_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pfnameh (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called
